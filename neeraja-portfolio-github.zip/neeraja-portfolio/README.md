# Neeraja Bevara — Portfolio

A responsive React portfolio built with Vite.

## Run it locally

1. Install Node.js from https://nodejs.org/
2. Extract this folder and open it in VS Code.
3. Open the terminal in this folder and run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL shown in your terminal.

## Personalise before publishing

Search the project for these placeholders and replace them:
- `YOUR-GITHUB-USERNAME`
- `YOUR-LINKEDIN-USERNAME`
- `YOUR-EMAIL@example.com`

Review the education names and percentages to ensure they are accurate. The project cards are labelled as ideas/learning builds; replace them with real project repositories after you complete and upload those projects.

## Upload to GitHub

1. Create a new repository on GitHub, for example `neeraja-portfolio`.
2. Upload the contents of this folder (not the ZIP file itself) to that repository.
3. Commit the files.
4. To publish the website, go to the repository's **Settings → Pages**. For a Vite app, GitHub Pages needs a build/deploy workflow or a compatible deployment service; simply uploading the source files will not publish the React app automatically.

## Build check

```bash
npm run build
```
