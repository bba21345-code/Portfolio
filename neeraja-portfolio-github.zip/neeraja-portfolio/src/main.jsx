import React from "react";
import { createRoot } from "react-dom/client";
import { Github, Linkedin, Mail, ArrowUpRight, Code2, BrainCircuit, GraduationCap, Sparkles } from "lucide-react";
import "./style.css";

const skills = ["Python", "Java", "C", "HTML", "CSS", "JavaScript", "SQL", "DBMS"];

const projects = [
  {
    number: "01",
    title: "Sudoku Web App",
    type: "Frontend practice",
    description: "A beginner-friendly Sudoku interface to practise JavaScript logic, UI design, and interactive web development.",
    tags: ["HTML", "CSS", "JavaScript"],
    link: "https://github.com/YOUR-GITHUB-USERNAME"
  },
  {
    number: "02",
    title: "Student Marks Dashboard",
    type: "Data practice",
    description: "A planned mini-project to organise student marks and explore simple summaries and visualisations.",
    tags: ["Python", "Pandas", "Matplotlib"],
    link: "https://github.com/YOUR-GITHUB-USERNAME"
  },
  {
    number: "03",
    title: "AI Learning Projects",
    type: "Currently exploring",
    description: "A space for small experiments as I learn AI concepts, strengthen problem-solving, and build practical projects.",
    tags: ["Python", "AI", "Problem-solving"],
    link: "https://github.com/YOUR-GITHUB-USERNAME"
  }
];

function App() {
  return (
    <div className="site-shell">
      <nav className="nav container">
        <a className="brand" href="#home"><span className="brand-mark">N</span> neeraja<span className="dot">.</span></a>
        <div className="nav-links">
          <a href="#about">About</a><a href="#skills">Skills</a><a href="#projects">Projects</a><a href="#education">Education</a>
        </div>
        <a className="nav-cta" href="#contact">Let's connect <ArrowUpRight size={15} /></a>
      </nav>

      <main>
        <section className="hero container" id="home">
          <div className="hero-copy">
            <div className="eyebrow"><span className="status-dot" /> CSE STUDENT · ASPIRING DEVELOPER</div>
            <h1>Learning today.<br /><span>Building what's next.</span></h1>
            <p className="hero-text">Hi, I'm <strong>Neeraja Bevara</strong> — a B.Tech Computer Science student interested in AI, technology, and solving real-world problems through code.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#projects">Explore my work <ArrowUpRight size={17} /></a>
              <a className="button button-ghost" href="#about">A little about me</a>
            </div>
            <div className="hero-note"><Sparkles size={15} /> Growing my skills one project at a time.</div>
          </div>
          <div className="hero-art" aria-label="Decorative coding illustration">
            <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
            <div className="glow"></div>
            <div className="code-card">
              <div className="window-dots"><i></i><i></i><i></i><span>neeraja.py</span></div>
              <div className="code-lines">
                <p><span className="line-no">01</span><span className="purple">class</span> <span className="cyan">Developer</span>:</p>
                <p><span className="line-no">02</span>&nbsp;&nbsp;name = <span className="green">"Neeraja"</span></p>
                <p><span className="line-no">03</span>&nbsp;&nbsp;focus = [</p>
                <p><span className="line-no">04</span>&nbsp;&nbsp;&nbsp;&nbsp;<span className="green">"AI"</span>, <span className="green">"Web"</span>,</p>
                <p><span className="line-no">05</span>&nbsp;&nbsp;&nbsp;&nbsp;<span className="green">"Problem-solving"</span></p>
                <p><span className="line-no">06</span>&nbsp;&nbsp;]</p>
                <p><span className="line-no">07</span>&nbsp;&nbsp;<span className="purple">def</span> <span className="yellow">keep_learning</span>():</p>
                <p><span className="line-no">08</span>&nbsp;&nbsp;&nbsp;&nbsp;<span className="purple">return</span> <span className="green">"always"</span></p>
                <p className="cursor-line"><span className="line-no">09</span><span className="cursor"></span></p>
              </div>
            </div>
            <div className="float-chip chip-ai"><BrainCircuit size={17} /><span>AI curious</span></div>
            <div className="float-chip chip-code"><Code2 size={17} /><span>Code & create</span></div>
            <div className="hero-orb">N<span>.</span></div>
          </div>
          <a className="scroll-cue" href="#about"><span></span> SCROLL TO EXPLORE</a>
        </section>

        <section className="about section container" id="about">
          <div className="section-label">01 / ABOUT ME</div>
          <div className="about-grid">
            <h2>Curious mind.<br /><span>Consistent growth.</span></h2>
            <div className="about-copy">
              <p>I'm a third-year B.Tech CSE student at <strong>Dhanekula Institute of Engineering and Technology</strong>. I'm strengthening my programming fundamentals and problem-solving skills while exploring how technology can make everyday tasks better.</p>
              <p>I enjoy learning new tools, exploring AI, and turning what I learn into small practical projects. I'm looking forward to collaborating, gaining hands-on experience, and growing into a thoughtful software professional.</p>
              <div className="values"><span>01 — Learn by doing</span><span>02 — Stay curious</span><span>03 — Build with purpose</span></div>
            </div>
          </div>
        </section>

        <section className="skills section" id="skills">
          <div className="container">
            <div className="section-label">02 / MY TOOLKIT</div>
            <div className="section-heading"><h2>Skills I'm <span>building.</span></h2><p>My current foundations — improving with practice and projects.</p></div>
            <div className="skill-grid">
              {skills.map((skill, i) => <div className="skill-card" key={skill}><span className="skill-index">0{i + 1}</span><span>{skill}</span><span className="skill-arrow">↗</span></div>)}
            </div>
            <p className="skill-footnote">I believe in being honest about what I know and improving through hands-on practice.</p>
          </div>
        </section>

        <section className="projects section container" id="projects">
          <div className="section-label">03 / SELECTED WORK</div>
          <div className="section-heading projects-heading"><h2>Ideas into <span>practice.</span></h2><p>Project ideas and learning builds. Replace these with your finished projects as you publish them.</p></div>
          <div className="project-list">
            {projects.map(project => <article className="project-card" key={project.number}>
              <div className="project-number">{project.number}</div>
              <div className="project-content"><div className="project-type">{project.type}</div><h3>{project.title}</h3><p>{project.description}</p><div className="tags">{project.tags.map(tag => <span key={tag}>{tag}</span>)}</div></div>
              <a className="project-link" href={project.link} target="_blank" rel="noreferrer" aria-label={`Open GitHub for ${project.title}`}><ArrowUpRight size={21} /></a>
            </article>)}
          </div>
        </section>

        <section className="education section" id="education">
          <div className="container">
            <div className="section-label">04 / EDUCATION</div>
            <div className="section-heading"><h2>The learning <span>journey.</span></h2></div>
            <div className="timeline">
              <div className="timeline-item"><div className="timeline-dot"></div><div className="timeline-date">CURRENT · B.TECH</div><h3>B.Tech — Computer Science & Engineering</h3><p>Dhanekula Institute of Engineering and Technology</p><span className="timeline-tag">3rd Year</span></div>
              <div className="timeline-item"><div className="timeline-dot"></div><div className="timeline-date">INTERMEDIATE</div><h3>Intermediate</h3><p>Narayana Junior College</p><span className="timeline-tag">90%</span></div>
              <div className="timeline-item"><div className="timeline-dot"></div><div className="timeline-date">SECONDARY EDUCATION</div><h3>10th Standard</h3><p>Ideal High School / Ideal CIS</p><span className="timeline-tag">90%</span></div>
            </div>
          </div>
        </section>

        <section className="contact section container" id="contact">
          <div className="contact-panel">
            <div className="section-label">05 / SAY HELLO</div>
            <h2>Let's make<br /><span>something useful.</span></h2>
            <p>I'm learning, building, and open to connecting with people who enjoy technology and sharing ideas.</p>
            <div className="contact-links">
              <a href="mailto:YOUR-EMAIL@example.com"><Mail size={17} /> Email me <ArrowUpRight size={15} /></a>
              <a href="https://github.com/YOUR-GITHUB-USERNAME" target="_blank" rel="noreferrer"><Github size={17} /> GitHub <ArrowUpRight size={15} /></a>
              <a href="https://www.linkedin.com/in/YOUR-LINKEDIN-USERNAME/" target="_blank" rel="noreferrer"><Linkedin size={17} /> LinkedIn <ArrowUpRight size={15} /></a>
            </div>
          </div>
        </section>
      </main>
      <footer className="footer container"><a className="brand" href="#home"><span className="brand-mark">N</span> neeraja<span className="dot">.</span></a><span>Designed with curiosity and a little bit of code.</span><a href="#home">Back to top ↑</a></footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<React.StrictMode><App /></React.StrictMode>);